#' Tutorials for Introductory Statistics
#'
#' @description
#'
#' This package supports online teaching for teaching introductory stats
#'
#' @import ggplot2 lsr
#' @docType package
#' @name IntroTutorials
#'
#'
#'
NULL
